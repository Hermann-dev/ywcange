<?php
/* Add extra type on visual composer */
require_once PIXI_INCLUDES.'types/pixi_template.php';
require_once PIXI_INCLUDES.'types/pixi_template_img.php';
require_once PIXI_INCLUDES.'types/pixi_template_imgclass.php';
